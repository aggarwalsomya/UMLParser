package com.somya.UMLParser2;

public class VarInfo {
	String scope;
	String dataType;
	String varName;
}
