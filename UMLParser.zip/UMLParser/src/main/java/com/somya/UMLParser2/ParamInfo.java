package com.somya.UMLParser2;

public class ParamInfo {
	String paramName;
	String returnType;
}